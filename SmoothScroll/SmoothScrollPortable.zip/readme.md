# SmoothScroll portable
## [Download](SmoothScroll.zip)
## [russian readme file](readmeRU.md)

## To start run [start.exe](start.exe)
## To add file to autorun you must make shortcut to [start.exe](start.exe) and put it to `%AppData%\Microsoft\Windows\Start Menu\Programs\Startup`
## If you add it to startup in any other way, the program will not start.


This is not a cracked SmoothScroll,
the file is not modified.
The only change made is that the program is made portable.

The [start.exe](start.exe) file resets the license file
and then launches the program,
so that the 21-day trial period starts again,
while all settings are saved.

You can put this file into autorun
and use the trial version indefinitely.

This is  not SmoothScroll repack
and not SmoothScroll crack.

Also, the program is disabled access to the Internet, so it will not be able to automatically update.
