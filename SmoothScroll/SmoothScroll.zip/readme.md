# SmoothScroll portable
## [Download](https://github.com/gmankab/portable-soft/releases/download/SmoothScroll/SmoothScroll-Portable.zip)

# To start run [start.exe](start.exe) or [start.bat](start.bat) or [start.vbs](start.vbs)


This is not a cracked SmoothScroll,
the file is not modified.
The only change made is that the program is made portable.

The start.exe or start.bat or start.vbs files resets the license file
and then launches the program,
so that the 21-day trial period starts again,
while all settings are saved.

You can put this file into autorun
and use the trial version indefinitely.

This is  not SmoothScroll repack
and not SmoothScroll crack.

Also, the program is disabled access to the Internet, so it will not be able to automatically update.
